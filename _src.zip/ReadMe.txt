Code files present for chapters 3,4,5, and 6.

There are no code files for chapters 1,2, and 7