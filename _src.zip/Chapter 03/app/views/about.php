<h2>About this site</h2>
<p>There are over <?php echo $number_of_cats; ?> cats on this site!</p>

